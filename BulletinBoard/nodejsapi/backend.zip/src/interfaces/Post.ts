export interface PostCreate {
    title: string;
    description: string;
    created_user_id: any;
}